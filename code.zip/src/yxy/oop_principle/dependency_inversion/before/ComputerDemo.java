package yxy.oop_principle.dependency_inversion.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:19
 * 此模式只能使用固定品牌的硬件，如果需要更换硬件，需要修改源代码
 */
public class ComputerDemo {

    public static void main(String[] args) {
        //创建组件
        XiJieHardDisk hardDisk = new XiJieHardDisk();
        IntelCpu cpu = new IntelCpu();
        KingstonMemory memory = new KingstonMemory();

        //创建计算机对象
        Computer computer = new Computer();
        //组装计算机
        computer.setCpu(cpu);
        computer.setHardDisk(hardDisk);
        computer.setMemory(memory);

        //运行计算机
        computer.run();

    }
}
