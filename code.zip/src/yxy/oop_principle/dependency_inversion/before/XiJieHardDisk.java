package yxy.oop_principle.dependency_inversion.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:16
 * 西捷硬盘
 */
public class XiJieHardDisk {
    //存储数据
    public void save(String data){
        System.out.println("西捷硬盘存储数据："+data);
    }

    //获取数据
    public String get(){
        System.out.println("西捷硬盘获取数据");
        return "数据";
    }
}
