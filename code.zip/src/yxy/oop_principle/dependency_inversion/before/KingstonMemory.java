package yxy.oop_principle.dependency_inversion.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:17
 */
public class KingstonMemory {
    //存储数据
    public void save(){
        System.out.println("使用金士顿内存");
    }

}
