package yxy.oop_principle.dependency_inversion.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:17
 */
public class IntelCpu {
    //运算
    public void run(){
        System.out.println("IntelCpu运算");
    }
}
