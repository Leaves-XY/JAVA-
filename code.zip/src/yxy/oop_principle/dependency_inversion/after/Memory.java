package yxy.oop_principle.dependency_inversion.after;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:24
 */
public interface Memory {
    //存储数据
    void save();

}
