package yxy.oop_principle.dependency_inversion.after;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:23
 */
public interface Cpu {
    public void run();
}
