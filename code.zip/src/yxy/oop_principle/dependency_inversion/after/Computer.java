package yxy.oop_principle.dependency_inversion.after;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:24
 */
public class Computer {
    private Cpu cpu;
    private Memory memory;
    private HardDisk hardDisk;


    public void run(){
        System.out.println("运行计算机");
        String data = hardDisk.get();
        System.out.println("从硬盘获取的数据是："+data);
        cpu.run();
        memory.save();
    }

    public Cpu getCpu() {
        return cpu;
    }

    public void setCpu(Cpu cpu) {
        this.cpu = cpu;
    }

    public Memory getMemory() {
        return memory;
    }

    public void setMemory(Memory memory) {
        this.memory = memory;
    }

    public HardDisk getHardDisk() {
        return hardDisk;
    }

    public void setHardDisk(HardDisk hardDisk) {
        this.hardDisk = hardDisk;
    }
}
