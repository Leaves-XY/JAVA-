package yxy.oop_principle.dependency_inversion.after;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:23
 */
public interface HardDisk {
    //存储数据
    void save(String data);

    //获取数据
    String get();
}
