package yxy.oop_principle.dependency_inversion.after;


/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:19
 * 依赖倒置原则
 */
public class ComputerDemo {

    public static void main(String[] args) {
        //创建组件
        HardDisk hardDisk = new XiJieHardDisk();
        Cpu cpu = new IntelCpu();
        Memory memory = new KingstonMemory();

        //创建计算机对象
        Computer computer = new Computer();

        //组装计算机
        computer.setCpu(cpu);
        computer.setHardDisk(hardDisk);
        computer.setMemory(memory);

        //运行计算机
        computer.run();

    }
}
