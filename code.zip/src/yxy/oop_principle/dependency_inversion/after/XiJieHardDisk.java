package yxy.oop_principle.dependency_inversion.after;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:23
 */
public class XiJieHardDisk implements HardDisk{
    //存储数据
    @Override
    public void save(String data){
        System.out.println("西捷硬盘存储数据："+data);
    }

    //获取数据
    @Override
    public String get(){
        System.out.println("西捷硬盘获取数据");
        return "数据";
    }
}
