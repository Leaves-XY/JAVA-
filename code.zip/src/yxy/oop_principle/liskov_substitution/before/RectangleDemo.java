package yxy.oop_principle.liskov_substitution.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 20:56
 */
public class RectangleDemo {
    public static void main(String[] args) {
        Rectangle rectangle = new Rectangle();
        rectangle.setLength(20);
        rectangle.setWidth(10);
        //拓宽
        resize(rectangle);
        printLengthAndWidth(rectangle);

        System.out.println("====================================");
        //正方形
        Rectangle square = new Square();
        square.setLength(20);
        //拓宽
        resize(square);
        printLengthAndWidth(square);

    }

    //拓宽方法
    public static void resize(Rectangle rectangle){
        while (rectangle.getWidth() <= rectangle.getLength()){
            rectangle.setWidth(rectangle.getWidth() + 1);
        }
        System.out.println("resize方法结束 width:"+rectangle.getWidth()+" length:"+rectangle.getLength());
    }

    //打印长宽
    public static void printLengthAndWidth(Rectangle rectangle){
        System.out.println("width:"+rectangle.getWidth()+" length:"+rectangle.getLength());
    }
}
