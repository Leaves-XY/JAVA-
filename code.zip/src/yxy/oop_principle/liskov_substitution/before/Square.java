package yxy.oop_principle.liskov_substitution.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 20:53
 * 正方形
 */
public class Square extends Rectangle{
    @Override
    public void setLength(double length) {
        super.setLength(length);
        super.setWidth(length);
    }

    @Override
    public void setWidth(double width) {
        super.setWidth(width);
        super.setLength(width);
    }
}
