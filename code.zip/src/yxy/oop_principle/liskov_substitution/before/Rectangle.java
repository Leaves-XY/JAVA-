package yxy.oop_principle.liskov_substitution.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 20:52
 * 长方形
 */
public class Rectangle {
    private double length;
    private double width;

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }
}
