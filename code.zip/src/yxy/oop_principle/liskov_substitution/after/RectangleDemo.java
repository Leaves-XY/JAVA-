package yxy.oop_principle.liskov_substitution.after;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:10
 */
public class RectangleDemo {
    public static void main(String[] args) {
        Rectangle rectangle = new Rectangle();
        rectangle.setLength(20);
        rectangle.setWidth(10);
        //拓宽
        resize(rectangle);
        printLengthAndWidth(rectangle);

        System.out.println("====================================");

    }

    public static void resize(Rectangle rectangle){
        while (rectangle.getWidth() <= rectangle.getLength()){
            rectangle.setWidth(rectangle.getWidth() + 1);
        }
        System.out.println("resize方法结束 width:"+rectangle.getWidth()+" length:"+rectangle.getLength());
    }

    public static void printLengthAndWidth(Quadrilateral quadrilateral){
        System.out.println("width:"+quadrilateral.getWidth()+" length:"+quadrilateral.getLength());
    }
}
