package yxy.oop_principle.liskov_substitution.after;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:08
 */
public class Square implements Quadrilateral{
    private double side;

    public double getSide() {
        return side;
    }

    public void setSide(double side) {
        this.side = side;
    }

    @Override
    public double getWidth() {
        return side;
    }

    @Override
    public double getLength() {
        return side;
    }
}

