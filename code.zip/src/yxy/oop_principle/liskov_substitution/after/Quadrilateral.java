package yxy.oop_principle.liskov_substitution.after;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:08
 */
public interface Quadrilateral {
    double getWidth();
    double getLength();
}
