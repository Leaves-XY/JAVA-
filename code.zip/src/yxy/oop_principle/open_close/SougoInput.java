package yxy.oop_principle.open_close;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/17 23:52
 * 搜狗输入法
 */
public class SougoInput {
    private AbstractSkin skin;

    public void setSkin(AbstractSkin skin) {
        this.skin = skin;
    }

    public void display(){
        skin.display();
    }
}
