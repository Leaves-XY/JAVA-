package yxy.oop_principle.open_close;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/17 23:53
 */
public class Client {
    public static void main(String[] args) {
        //创建搜狗输入法对象
        SougoInput sougoInput = new SougoInput();
        //创建默认皮肤对象
        sougoInput.setSkin(new DefaultSkin());
        sougoInput.display();
        //创建yxy皮肤对象
        sougoInput.setSkin(new YxySkin());
        sougoInput.display();
    }
}
