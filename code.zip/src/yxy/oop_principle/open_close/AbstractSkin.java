package yxy.oop_principle.open_close;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/17 23:50
 * 抽象皮肤类
 */
public abstract class AbstractSkin {
    //显示方法
    public abstract void display();
}
