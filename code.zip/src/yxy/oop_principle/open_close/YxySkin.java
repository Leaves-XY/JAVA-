package yxy.oop_principle.open_close;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/17 23:52
 * yxy皮肤类
 */
public class YxySkin extends AbstractSkin{
    @Override
    public void display(){
        System.out.println("yxy皮肤");
    }
}
