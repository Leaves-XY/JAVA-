package yxy.oop_principle.open_close;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/17 23:51
 * 默认皮肤类
 */
public class DefaultSkin extends AbstractSkin {
    @Override
    public void display() {
        System.out.println("默认皮肤");
    }
}
