package yxy.oop_principle.composite_reuse;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 22:26
 */
public class ElectricCar extends Car{
    public void move(){
        System.out.println("电动车移动");
    }

    public void setColor(Color color){
        super.setColor(new Red());
    }
}
