package yxy.oop_principle.composite_reuse;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 22:20
 */
public class Car {
    private Color color;

    public void setColor(Color color){
        this.color = color;
    }

    public void move(){
        System.out.println("汽车移动");
    }
}
