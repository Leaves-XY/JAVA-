package yxy.oop_principle.composite_reuse;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 22:21
 */
public class PetrolCar extends Car{


    public void move(){
        System.out.println("汽油车移动");
    }

    public void setColor(Color color){
        super.setColor(new White());
    }
}
