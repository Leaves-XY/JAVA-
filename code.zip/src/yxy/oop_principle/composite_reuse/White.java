package yxy.oop_principle.composite_reuse;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 22:22
 */
public class White implements Color{
}
