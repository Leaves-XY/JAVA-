package yxy.oop_principle.demeter;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:44
 */
public class Fans {
    private String name;

    public Fans(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
