package yxy.oop_principle.demeter;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:41.
 * 经纪人
 */
public class Agent {
    private Star star;
    private Fans fans;
    private Company company;

    //和粉丝见面
    public void meeting(){
        System.out.println(star.getName()+"和粉丝"+fans.getName()+"见面");
    }

    //和媒体公司洽谈
    public void business(){
        System.out.println(star.getName()+"和媒体公司"+company.getName()+"洽谈");
    }

    public Star getStar() {
        return star;
    }

    public void setStar(Star star) {
        this.star = star;
    }

    public Fans getFans() {
        return fans;
    }

    public void setFans(Fans fans) {
        this.fans = fans;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }
}
