package yxy.oop_principle.demeter;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 22:08
 * 迪米特里法则
 */
public class Client {
    public static void main(String[] args) {
        Agent agent = new Agent();
        Star star = new Star("李健");
        Fans fans = new Fans("李四");
        Company company = new Company("腾讯媒体公司");
        agent.setFans(fans);
        agent.setStar(star);
        agent.setCompany(company);
        agent.meeting();
        agent.business();
    }
}
