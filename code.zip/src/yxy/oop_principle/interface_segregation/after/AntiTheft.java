package yxy.oop_principle.interface_segregation.after;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:35
 */
public interface AntiTheft {
    void antiTheft();
}
