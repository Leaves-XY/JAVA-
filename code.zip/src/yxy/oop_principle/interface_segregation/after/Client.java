package yxy.oop_principle.interface_segregation.after;


import yxy.oop_principle.interface_segregation.before.SafetyDoor;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:36
 * 接口隔离原则
 */
public class Client {
    public static void main(String[] args) {
        HeimaSafeDoor heimaSafeDoor = new HeimaSafeDoor();
        heimaSafeDoor.antiTheft();
        heimaSafeDoor.fireproof();
        heimaSafeDoor.waterproof();

        System.out.println("====================================");

        ItcastSafeDoor itcastSafeDoor = new ItcastSafeDoor();
        itcastSafeDoor.antiTheft();
        itcastSafeDoor.fireproof();

    }
}
