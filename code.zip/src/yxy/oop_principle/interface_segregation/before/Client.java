package yxy.oop_principle.interface_segregation.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:34
 * 如果一个类实现了一个接口，那么这个类中必须实现这个接口的所有方法(不防水，但是实现了防水接口，必须实现防水方法)
 */
public class Client {
    public static void main(String[] args) {
        SafetyDoor safetyDoor = new HeimaSafeDoor();
        safetyDoor.antiTheft();
        safetyDoor.fireproof();
        safetyDoor.waterproof();
    }
}
