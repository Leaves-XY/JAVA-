package yxy.oop_principle.interface_segregation.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:33
 * 安全门接口
 */
public interface SafetyDoor {
    //防盗
    void antiTheft();

    //防火
    void fireproof();

    //防水
    void waterproof();
}
