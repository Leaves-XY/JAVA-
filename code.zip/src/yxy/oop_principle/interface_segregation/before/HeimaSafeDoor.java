package yxy.oop_principle.interface_segregation.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 21:33
 */
public class HeimaSafeDoor implements SafetyDoor{
    @Override
    public void antiTheft() {
        System.out.println("防盗");
    }

    @Override
    public void fireproof() {
        System.out.println("防火");
    }

    @Override
    public void waterproof() {
        System.out.println("防水");
    }
}
