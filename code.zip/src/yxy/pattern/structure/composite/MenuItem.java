package yxy.pattern.structure.composite;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 21:38
 * 菜单项 叶子节点
 */
public class MenuItem extends MenuComponent {
    public MenuItem(String name, int level) {
        this.name = name;
        this.level = level;
    }

    public void print() {
        //级别
        for (int i = 0; i < level; i++) {
            System.out.print("--");
        }

        //打印菜单名称
        System.out.println(name);
    }


}
