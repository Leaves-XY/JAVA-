package yxy.pattern.structure.composite;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 21:32
 * 菜单组件
 */
public abstract class MenuComponent {
    protected String name;
    protected int level;

    //添加子菜单
    public void add(MenuComponent menuComponent) {
        throw new UnsupportedOperationException();
    }

    //删除子菜单
    public void remove(MenuComponent menuComponent) {
        throw new UnsupportedOperationException();
    }

    //获取指定子菜单
    public MenuComponent getChild(int index) {
        throw new UnsupportedOperationException();
    }

    //获取菜单名称
    public String getName() {
        return name;
    }

    //打印菜单名称(包含子菜单)
    public abstract void print() ;


}
