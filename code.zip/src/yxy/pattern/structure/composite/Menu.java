package yxy.pattern.structure.composite;

import java.util.ArrayList;
import java.util.List;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 21:35
 * 菜单 树枝节点
 */
public class Menu extends MenuComponent{
    private List<MenuComponent> menuComponentList=new ArrayList<>();

    public Menu(String name, int level) {
        this.level = level;
        this.name = name;
    }

    @Override
    public void add(MenuComponent menuComponent) {
        menuComponentList.add(menuComponent);
    }

    @Override
    public void remove(MenuComponent menuComponent) {
        menuComponentList.remove(menuComponent);
    }

    @Override
    public MenuComponent getChild(int index) {
        return menuComponentList.get(index);
    }

    @Override
    public void print() {
        //级别
        for (int i = 0; i < level; i++) {
            System.out.print("--");
        }

        //打印菜单名称
        System.out.println(name);
        //打印子菜单
        for (MenuComponent menuComponent : menuComponentList) {
            menuComponent.print();
        }
    }
}
