package yxy.pattern.structure.fly_weight;

import java.util.HashMap;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 22:11
 */
public class BoxFactory {
    private HashMap<String, AbstractBox> map;

    //构造方法初始化
    public BoxFactory() {
        map = new HashMap<>();
        map.put("I", new IBox());
        map.put("O", new OBox());
        map.put("L", new LBox());
    }

    //提供一个方法获取该工厂对象
    public static BoxFactory getInstance() {
        return instance;
    }

    private static BoxFactory instance = new BoxFactory();

    //根据名称获取图形对象
    public AbstractBox getBox(String name) {
        return map.get(name);
    }

}
