package yxy.pattern.structure.fly_weight;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 22:08
 * 享元模式 抽象享元类
 */
public abstract class AbstractBox {
    //获取图形的方法
    public abstract String getShape();

    //显示图形及颜色
    public void display(String color) {
        System.out.println("方块形状：" + getShape() + " 颜色：" + color);
    }
}
