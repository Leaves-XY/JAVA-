package yxy.pattern.structure.fly_weight;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 22:11
 */
public class OBox extends AbstractBox{
    @Override
    public String getShape() {
        return "O";
    }
}
