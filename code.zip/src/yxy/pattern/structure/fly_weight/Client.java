package yxy.pattern.structure.fly_weight;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 22:19
 */
public class Client {
    public static void main(String[] args) {
        AbstractBox box1 = BoxFactory.getInstance().getBox("I");
        box1.display("灰色");
        AbstractBox box2 = BoxFactory.getInstance().getBox("L");
        box2.display("绿色");
        AbstractBox box3 = BoxFactory.getInstance().getBox("O");
        box3.display("黄色");
        AbstractBox box4 = BoxFactory.getInstance().getBox("O");
        box4.display("红色");

        System.out.println("两次获取的O方块是否是同一个对象：" + (box3 == box4));
    }
}
