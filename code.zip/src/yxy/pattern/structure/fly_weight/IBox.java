package yxy.pattern.structure.fly_weight;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 22:10
 * 具体享元类
 */
public class IBox extends AbstractBox{
    @Override
    public String getShape() {
        return "I";
    }
}
