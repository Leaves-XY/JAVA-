package yxy.pattern.structure.proxy.static_proxy;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:21
 */
public class Client {
    public static void main(String[] args) {
        //创建代售点对象
        ProxyPoint proxyPoint = new ProxyPoint();
        //调用方法
        proxyPoint.sell();
    }
}
