package yxy.pattern.structure.proxy.static_proxy;

import yxy.pattern.structure.proxy.jdk_proxy.SellTickets;
import yxy.pattern.structure.proxy.jdk_proxy.TrainStation;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:20
 * 代售点
 */
public class ProxyPoint implements SellTickets {
    //声明火车站类对象
    private TrainStation trainStation = new TrainStation();

    @Override
    public void sell() {
        System.out.println("代售点收取一些服务费");
        trainStation.sell();
    }

}
