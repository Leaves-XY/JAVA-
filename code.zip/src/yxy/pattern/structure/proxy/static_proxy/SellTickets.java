package yxy.pattern.structure.proxy.static_proxy;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:18
 * 卖票接口
 */
public interface SellTickets {
    void sell();
}
