package yxy.pattern.structure.proxy.jdk_proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:24
 * 代理工厂
 */
public class ProxyFactory {
    //声明目标对象
    private TrainStation trainStation = new TrainStation();

    public SellTickets getProxyObject(){
        //返回代理对象
        /**
         * 1.类加载器,获取加载器的方法固定
         * 2.接口,代理类实现的接口列表
         * 3.处理器,事件处理,执行目标对象的方法时,会触发事件处理器的方法,会把当前执行的目标对象方法作为参数传入
         */
        return (SellTickets) Proxy.newProxyInstance(
                trainStation.getClass().getClassLoader(),
                trainStation.getClass().getInterfaces(),
                new InvocationHandler() {
                    /**
                     * proxy:代理对象
                     * method:代理对象调用的方法,被封装为对象
                     * args:代理对象调用的方法时,传递的实际参数
                     * 返回值:当前执行方法的返回值
                     */
                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                        System.out.println("代理点收取一些服务费用(jdk动态代理)");
                        //执行目标对象的方法
                        //参数 1:目标对象,参数 2:方法实际参数
                        Object obj = method.invoke(trainStation, args);
                        return obj;
                    }
                }
        );

    }
}
