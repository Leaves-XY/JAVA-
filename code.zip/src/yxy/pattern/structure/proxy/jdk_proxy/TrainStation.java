package yxy.pattern.structure.proxy.jdk_proxy;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:18
 */
public class TrainStation implements SellTickets{
    @Override
    public void sell() {
        System.out.println("火车站卖票");
    }
}
