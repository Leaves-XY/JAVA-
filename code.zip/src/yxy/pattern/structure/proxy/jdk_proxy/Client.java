package yxy.pattern.structure.proxy.jdk_proxy;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:29
 */
public class Client {
    public static void main(String[] args) {
        //创建代理对象
        ProxyFactory factory = new ProxyFactory();
        //获取代理对象
        SellTickets proxyObject = factory.getProxyObject();
        //调用卖票方法
        proxyObject.sell();
    }
}
