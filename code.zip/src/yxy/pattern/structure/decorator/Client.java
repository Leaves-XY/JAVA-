package yxy.pattern.structure.decorator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 23:17
 */
public class Client {
    public static void main(String[] args) {
        //点一份炒饭
        FastFood firedRice = new FiredRice();
        System.out.println(firedRice.getDesc()+"  "+firedRice.cost()+"元");

        //上面炒饭加鸡蛋
        FastFood firedRiceWithEgg = new Egg(firedRice);
        System.out.println(firedRiceWithEgg.getDesc()+"  "+firedRiceWithEgg.cost()+"元");

        //再加培根
        FastFood firedRiceWithEggWithBacon = new Bacon(firedRiceWithEgg);
        System.out.println(firedRiceWithEggWithBacon.getDesc()+"  "+firedRiceWithEggWithBacon.cost()+"元");

        //点一份炒面
        FastFood friedNoodles = new FiredNoodles();
        System.out.println(friedNoodles.getDesc()+"  "+friedNoodles.cost()+"元");

        //上面炒面加两个鸡蛋
        FastFood friedNoodlesWithTwoEgg = new Egg(new Egg(friedNoodles));
        System.out.println(friedNoodlesWithTwoEgg.getDesc()+"  "+friedNoodlesWithTwoEgg.cost()+"元");
    }
}
