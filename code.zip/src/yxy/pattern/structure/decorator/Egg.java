package yxy.pattern.structure.decorator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 23:15
 * 具体装饰者 鸡蛋
 */
public class Egg extends Garnish{
    public Egg(FastFood fastFood) {
        super(1,"鸡蛋",fastFood);
    }

    @Override
    public float cost() {
        return super.getPrice()+super.getFastFood().cost();
    }

    @Override
    public String getDesc() {
        return super.getDesc()+" "+super.getPrice()+"&&"+super.getFastFood().getDesc();
    }
}
