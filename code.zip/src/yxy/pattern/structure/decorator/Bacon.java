package yxy.pattern.structure.decorator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 23:15
 * 具体装饰者 培根
 */
public class Bacon extends Garnish{
    public Bacon(FastFood fastFood) {
        super(2,"培根",fastFood);
    }

    @Override
    public float cost() {
        return super.getPrice()+super.getFastFood().cost();
    }

    @Override
    public String getDesc() {
        return super.getDesc()+" "+super.getPrice()+"&&"+super.getFastFood().getDesc();
    }
}
