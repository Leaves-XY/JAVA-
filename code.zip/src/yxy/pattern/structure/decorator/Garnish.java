package yxy.pattern.structure.decorator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 23:13
 * 装饰者 调料类
 */
public class Garnish extends FastFood{
    private FastFood fastFood;

    public Garnish(FastFood fastFood) {
        this.fastFood = fastFood;
    }

    public Garnish(float price, String desc, FastFood fastFood) {
        super(price, desc);
        this.fastFood = fastFood;
    }

    @Override
    public float cost() {
        return super.getPrice()+fastFood.cost();
    }

    @Override
    public String getDesc() {
        return super.getDesc()+" "+super.getPrice()+"&&"+fastFood.getDesc();
    }

    public FastFood getFastFood() {
        return fastFood;
    }

    public void setFastFood(FastFood fastFood) {
        this.fastFood = fastFood;
    }
}
