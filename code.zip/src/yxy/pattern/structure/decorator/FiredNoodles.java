package yxy.pattern.structure.decorator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 23:12
 * 具体被装饰者 炒面
 */
public class FiredNoodles extends FastFood{
    public FiredNoodles() {
        super(12,"炒面");
    }

    @Override
    public float cost() {
        return getPrice();
    }
}
