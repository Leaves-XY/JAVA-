package yxy.pattern.structure.decorator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 23:10
 * 具体被装饰者 炒饭
 */
public class FiredRice extends FastFood{
    public FiredRice() {
        super(10,"炒饭");
    }

    @Override
    public float cost() {
        return getPrice();
    }
}
