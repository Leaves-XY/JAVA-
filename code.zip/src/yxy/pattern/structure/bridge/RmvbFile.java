package yxy.pattern.structure.bridge;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 23:44
 * 具体实现类 rmvb文件
 */
public class RmvbFile implements VideoFile{
    @Override
    public void decode(String fileName) {
        System.out.println("rmvb解码"+fileName);
    }

    @Override
    public void play(String fileName) {
        System.out.println("rmvb播放");
    }
}
