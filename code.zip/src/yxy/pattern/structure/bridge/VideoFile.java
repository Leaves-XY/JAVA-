package yxy.pattern.structure.bridge;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 23:43
 * 视频文件接口
 */
public interface VideoFile {
    //解码
    void decode(String fileName);

    //播放
    void play(String fileName);
}
