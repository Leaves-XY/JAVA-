package yxy.pattern.structure.bridge;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 23:44
 */
public class AviFile implements VideoFile{
    @Override
    public void decode(String fileName) {
        System.out.println("avi解码"+fileName);
    }

    @Override
    public void play(String fileName) {
        System.out.println("avi播放");
    }
}
