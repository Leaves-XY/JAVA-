package yxy.pattern.structure.bridge;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 0:00
 */
public class Mac extends OperatingSystem{
    public Mac(VideoFile videoFile) {
        super(videoFile);
    }

    @Override
    public void play(String fileName) {
        videoFile.decode(fileName);
    }
}
