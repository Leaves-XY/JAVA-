package yxy.pattern.structure.bridge;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 23:55
 * 具体操作系统类
 */
public class Windows extends OperatingSystem{

    public Windows(VideoFile videoFile) {
        super(videoFile);
    }

    public void play(String fileName) {
        videoFile.decode(fileName);
    }

}

