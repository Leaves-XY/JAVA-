package yxy.pattern.structure.bridge;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 0:00
 */
public class Client {
    public static void main(String[] args) {
        OperatingSystem windows = new Windows(new AviFile());
        windows.play("战狼");
        OperatingSystem mac = new Mac(new RmvbFile());
        mac.play("丁真");
    }
}
