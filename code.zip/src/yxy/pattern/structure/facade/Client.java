package yxy.pattern.structure.facade;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 20:28
 */
public class Client {
    public static void main(String[] args) {
        SmartAppliancesFacade facade = new SmartAppliancesFacade();
        facade.say("打开");
        System.out.println("-------------");
        facade.say("关闭");
    }
}
