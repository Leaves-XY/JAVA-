package yxy.pattern.structure.facade;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 20:25
 */
public class Light {
    public void on(){
        System.out.println("打开灯...");
    }

    public void off(){
        System.out.println("关闭灯...");
    }
}
