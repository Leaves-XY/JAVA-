package yxy.pattern.structure.adapter.object_adapter;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:53
 */
public class Client {
    public static void main(String[] args) {
        //创建计算机对象
        Computer computer = new Computer();
        //读取SD卡中的数据
        String msg = computer.readSD(new SDCardImpl());
        System.out.println(msg);
        System.out.println("=============");

        //使用该电脑读取TF卡中的数据
        //定义适配器类
        SDAdapterTF sdAdapterTF = new SDAdapterTF(new TFCardImpl());
        String msg1 = computer.readSD(sdAdapterTF);
        System.out.println(msg1);


    }
}
