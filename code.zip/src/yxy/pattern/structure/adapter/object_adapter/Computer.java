package yxy.pattern.structure.adapter.object_adapter;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:53
 */
public class Computer {
    //从SD卡中读取数据
    public String readSD(SDCard sdCard) {
        if (sdCard == null) {
            throw new NullPointerException("sd card is null");
        }
        return sdCard.readSD();
    }
}
