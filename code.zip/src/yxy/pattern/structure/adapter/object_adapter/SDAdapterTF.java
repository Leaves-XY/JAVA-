package yxy.pattern.structure.adapter.object_adapter;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:54
 */
public class SDAdapterTF implements SDCard {
    //声明适配者类
    private TFCard tfCard;

    public SDAdapterTF(TFCard tfCard) {
        this.tfCard = tfCard;
    }

    @Override
    public String readSD() {
        System.out.println("适配器读TF卡");
        return tfCard.readTF();
    }

    @Override
    public void writeSD(String msg) {
        System.out.println("适配器写TF卡");
        tfCard.writeTF(msg);
    }
}
