package yxy.pattern.structure.adapter.class_adapter;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:52
 */
public class SDCardImpl implements SDCard{
    @Override
    public String readSD() {
        return "读取SD卡";
    }

    @Override
    public void writeSD(String msg) {
        System.out.println("写入SD卡："+msg);
    }
}
