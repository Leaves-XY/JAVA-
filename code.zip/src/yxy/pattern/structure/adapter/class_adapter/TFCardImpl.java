package yxy.pattern.structure.adapter.class_adapter;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:51
 */
public class TFCardImpl implements TFCard{
    @Override
    public String readTF() {
        return "TF卡读取数据";
    }

    @Override
    public void writeTF(String msg) {
        System.out.println("TF卡写入数据："+msg);
    }
}
