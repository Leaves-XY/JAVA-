package yxy.pattern.structure.adapter.class_adapter;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:54
 */
public class SDAdapterTF extends TFCardImpl implements SDCard{
    @Override
    public String readSD() {
        System.out.println("适配器读TF卡");
        return readTF();
    }

    @Override
    public void writeSD(String msg) {
        System.out.println("适配器写TF卡");
        writeTF(msg);
    }
}
