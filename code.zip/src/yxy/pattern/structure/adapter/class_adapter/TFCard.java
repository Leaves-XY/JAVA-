package yxy.pattern.structure.adapter.class_adapter;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:50
 * 类适配器模式
 * TF卡接口
 */
public interface TFCard {
    /**
     * 读取TF卡
     */
    String readTF();

    /**
     * 写入TF卡
     */
    void writeTF(String msg);
}
