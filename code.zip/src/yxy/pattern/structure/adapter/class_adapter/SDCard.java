package yxy.pattern.structure.adapter.class_adapter;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 22:52
 */
public interface SDCard {
    /**
     * 读取SD卡
     */
    String readSD();

    /**
     * 写入SD卡
     */
    void writeSD(String msg);
}
