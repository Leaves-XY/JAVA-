package yxy.pattern.behavior.template_method;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 22:46
 * 模板方法模式 抽象类
 */
public abstract class AbstractClass {
    //模板方法定义 顺序不能变(流程固定)
    public final void cookProcess(){
        this.pourOil();
        this.heatOil();
        this.pourVegetable();
        this.pourSauce();
        this.fry();
    }

    public void pourOil() {
        System.out.println("倒油");
    }

    public void heatOil() {
        System.out.println("热油");
    }

    //到蔬菜和调料品不一样
    public abstract void pourVegetable();

    public abstract void pourSauce();

    public void fry() {
        System.out.println("炒啊炒啊炒到熟啊");
    }

}
