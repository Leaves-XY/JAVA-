package yxy.pattern.behavior.template_method;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 22:50
 */
public class Client {
    public static void main(String[] args) {
        //炒包菜
        AbstractClass baoCai = new ConcreteClass_BaoCai();
        baoCai.cookProcess();
        System.out.println("----------");
        //炒菜心
        AbstractClass caiXin = new ConcreteClass_CaiXin();
        caiXin.cookProcess();

    }
}
