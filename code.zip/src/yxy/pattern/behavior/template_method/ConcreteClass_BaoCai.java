package yxy.pattern.behavior.template_method;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 22:49
 */
public class ConcreteClass_BaoCai extends AbstractClass{
    @Override
    public void pourVegetable() {
        System.out.println("下包菜");
    }

    @Override
    public void pourSauce() {
        System.out.println("下辣椒");
    }
}
