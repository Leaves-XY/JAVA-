package yxy.pattern.behavior.mediator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 21:07
 */
public class Client {
    public static void main(String[] args) {
        MediatorStructure mediator = new MediatorStructure();
        HouseOwner houseOwner = new HouseOwner("张三", mediator);
        Tenant tenant = new Tenant("李四", mediator);
        //中介者要知道房主和租房者
        mediator.setHouseOwner((houseOwner));
        mediator.setTenant( tenant);

        tenant.contact("我想租三室的房子");
        houseOwner.contact("我这里有三室的房子，你需要租吗？");


    }
}
