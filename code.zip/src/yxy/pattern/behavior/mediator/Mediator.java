package yxy.pattern.behavior.mediator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 20:54
 * 中介者模式 抽象中介者类
 */
public abstract class Mediator {
    public abstract void contact(String message,Person person);
}
