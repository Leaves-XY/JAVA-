package yxy.pattern.behavior.mediator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 20:55
 * 中介者模式 人员抽象类
 */
public abstract class Person {
    protected String name;
    protected Mediator mediator;

    public Person(String name, Mediator mediator) {
        this.name = name;
        this.mediator = mediator;
    }

}
