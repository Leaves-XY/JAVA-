package yxy.pattern.behavior.observer;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 20:31
 * 观察者接口
 */
public interface Observer {
    void update(String message);
}
