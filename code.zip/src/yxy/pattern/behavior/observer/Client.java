package yxy.pattern.behavior.observer;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 20:36
 */
public class Client {
    public static void main(String[] args) {
        SubscriptionSubject subscriptionSubject = new SubscriptionSubject();
        WeiXinUser weiXinUser1 = new WeiXinUser("张三");
        WeiXinUser weiXinUser2 = new WeiXinUser("李四");
        WeiXinUser weiXinUser3 = new WeiXinUser("王五");
        subscriptionSubject.attach(weiXinUser1);
        subscriptionSubject.attach(weiXinUser2);
        subscriptionSubject.attach(weiXinUser3);

        subscriptionSubject.notify("你好");

    }
}
