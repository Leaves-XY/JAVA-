package yxy.pattern.behavior.observer;

import java.util.ArrayList;
import java.util.List;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 20:33
 * 具体主题
 */
public class SubscriptionSubject implements Subject{

    //顶一个集合 用来存储所有的观察者对象
    private List<Observer> weixinUserlist = new ArrayList<Observer>();

    @Override
    public void attach(Observer observer) {
        weixinUserlist.add(observer);
    }

    @Override
    public void detach(Observer observer) {
        weixinUserlist.remove(observer);
    }

    @Override
    public void notify(String message) {
        for (Observer observer : weixinUserlist) {
            observer.update(message);
        }
    }
}
