package yxy.pattern.behavior.strategy;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 23:15
 * 策略模式
 */
public interface Strategy {
    void show();
}
