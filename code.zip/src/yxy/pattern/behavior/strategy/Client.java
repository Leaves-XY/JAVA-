package yxy.pattern.behavior.strategy;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 23:18
 */
public class Client {
    public static void main(String[] args) {
        SalesMan salesMan = new SalesMan(new StrategyA());
        salesMan.show();
        System.out.println("-------------");
        salesMan = new SalesMan(new StrategyB());
        salesMan.show();
        System.out.println("-------------");
        salesMan = new SalesMan(new StrategyC());
        salesMan.show();

    }
}
