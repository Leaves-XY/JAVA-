package yxy.pattern.behavior.strategy;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 23:15
 */
public class StrategyA implements Strategy{
    @Override
    public void show() {
        System.out.println("策略A");
    }
}
