package yxy.pattern.behavior.strategy;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/24 23:17
 * 环境角色 用来操作策略的上下文环境
 */
public class SalesMan {
    private Strategy strategy;

    public SalesMan(Strategy strategy) {
        this.strategy = strategy;
    }

    public void show(){
        strategy.show();
    }
}
