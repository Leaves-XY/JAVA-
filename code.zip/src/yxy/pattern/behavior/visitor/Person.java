package yxy.pattern.behavior.visitor;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 22:16
 */
public interface Person {
    void feed(Cat cat);

    void feed(Dog dog);
}
