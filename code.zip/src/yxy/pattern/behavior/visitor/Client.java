package yxy.pattern.behavior.visitor;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 22:30
 */
public class Client {
    public static void main(String[] args) {
        Home home=new Home();
        home.add(new Cat());
        home.add(new Dog());

        Owner owner=new Owner();
        //主人喂食所有动物
        home.action(owner);
    }
}
