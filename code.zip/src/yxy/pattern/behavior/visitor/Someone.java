package yxy.pattern.behavior.visitor;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 22:26
 */
public class Someone implements Person {
    @Override
    public void feed(Cat cat) {
        System.out.println("其他人喂食猫粮");
    }

    @Override
    public void feed(Dog dog) {
        System.out.println("其他人喂食狗粮");
    }
}

