package yxy.pattern.behavior.visitor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 22:27
 */
public class Home {
    //声明一个集合对象 用来存储元素对象
    private List<Animal> nodeList=new ArrayList<>();

    //添加元素的功能
    public void add(Animal animal){
        nodeList.add(animal);
    }

    //接受访问者的功能
    public void  action(Person person){
        //遍历集合中的所有元素,让访问者访问
        for (Animal animal : nodeList) {
            animal.accept(person);
        }
    }
}
