package yxy.pattern.behavior.visitor;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 22:25
 */
public class Owner implements Person{
    @Override
    public void feed(Cat cat) {
        System.out.println("主人喂食猫");
    }

    @Override
    public void feed(Dog dog) {
        System.out.println("主人喂食狗");
    }
}
