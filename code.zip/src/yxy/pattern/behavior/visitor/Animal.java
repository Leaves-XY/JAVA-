package yxy.pattern.behavior.visitor;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 22:18
 */
public interface Animal {
    //接受访问这访问的功能
    void accept(Person person);
}
