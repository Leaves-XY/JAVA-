package yxy.pattern.behavior.state.after;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 19:53
 * 环境角色类 Context 用于维护状态，定义当前状态
 */
public class Context {
    //定义出所有的电梯状态
    public final static OpeningState OPENING_STATE = new OpeningState();
    public final static ClosingState CLOSING_STATE = new ClosingState();
    public final static RunningState RUNNING_STATE = new RunningState();
    public final static StoppingState STOPPING_STATE = new StoppingState();

    //定义一个当前电梯状态
    private LiftState liftState;

    public LiftState getLiftState() {
        return liftState;
    }

    //设置当前电梯状态
    public void setLiftState(LiftState liftState) {
        this.liftState = liftState;
        //将当前环境通知到各个实现类中
        this.liftState.setContext(this);
    }

    public void open(){
        this.liftState.open();
    }

    public void close(){
        this.liftState.close();
    }

    public void run(){
        this.liftState.run();
    }

    public void stop(){
        this.liftState.stop();
    }
}
