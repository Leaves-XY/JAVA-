package yxy.pattern.behavior.state.after;


/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 19:53
 * 电梯状态抽象类
 */
public abstract class LiftState {
    //环境角色变量
    protected Context context;

    public void setContext(Context context) {
        this.context = context;
    }

    /**
     * 电梯开门
     */
    public abstract void open();

    /**
     * 电梯关门
     */
    public abstract void close();

    /**
     * 电梯运行
     */
    public abstract void run();

    /**
     * 电梯停止
     */
    public abstract void stop();

}
