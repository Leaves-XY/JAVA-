package yxy.pattern.behavior.state.after;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 20:12
 */
public class Client {
    public static void main(String[] args) {
        Context context = new Context();
        context.setLiftState(Context.RUNNING_STATE);
        context.open();
        context.close();
        context.run();
        context.stop();
    }
}
