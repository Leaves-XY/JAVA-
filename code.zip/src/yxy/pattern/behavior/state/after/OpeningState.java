package yxy.pattern.behavior.state.after;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 19:56
 */
public class OpeningState extends LiftState {
    @Override
    public void open() {
        System.out.println("电梯开启");
    }

    @Override
    public void close() {
        //状态修改
        super.context.setLiftState(Context.CLOSING_STATE);
        //动作委托为ClosingState来执行
        super.context.close();
    }

    @Override
    public void run() {
        //什么都不做
    }

    @Override
    public void stop() {
        //什么都不做
    }
}
