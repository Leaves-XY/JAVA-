package yxy.pattern.behavior.state.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 19:40
 * 问题:电梯的状态切换逻辑混乱,不易维护 且不符合开闭原则
 */
public class Client {
    public static void main(String[] args) {
        Lift lift = new Lift();
        lift.setState(ILift.OPENING_STATE);
        lift.open();
        lift.close();
        lift.run();
        lift.stop();
    }
}
