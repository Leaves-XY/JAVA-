package yxy.pattern.behavior.state.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 19:29
 * 电梯接口
 */
public interface ILift {
    //电梯的四个状态
    int OPENING_STATE=1;
    int CLOSING_STATE=2;
    int RUNNING_STATE=3;
    int STOPPING_STATE=4;

    void setState(int state);

    /**
     * 电梯开门
     */
    void open();

    /**
     * 电梯关门
     */
    void close();

    /**
     * 电梯运行
     */
    void run();

    /**
     * 电梯停止
     */
    void stop();
}
