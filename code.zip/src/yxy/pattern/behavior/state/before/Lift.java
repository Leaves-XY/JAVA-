package yxy.pattern.behavior.state.before;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 19:34
 * 电梯类
 */
public class Lift implements ILift{
    private int state;

    @Override
    public void setState(int state) {
        this.state=state;
    }

    @Override
    public void open() {
        switch (state){
            case OPENING_STATE:
                break;
            case CLOSING_STATE:
                System.out.println("电梯门开启");
                setState(OPENING_STATE);
                break;
            case STOPPING_STATE:
                System.out.println("电梯门开启");
                setState(OPENING_STATE);
                break;
            case RUNNING_STATE:
                break;
        }
    }

    @Override
    public void close() {
        switch (state){
            case OPENING_STATE:
                System.out.println("电梯门关闭");
                setState(CLOSING_STATE);
            case CLOSING_STATE:
                break;
            case STOPPING_STATE:
                System.out.println("电梯门关闭");
                setState(CLOSING_STATE);
                break;
            case RUNNING_STATE:
                break;
        }
    }

    @Override
    public void run() {
        switch (state){
            case OPENING_STATE:
                break;
            case CLOSING_STATE:
                System.out.println("电梯运行");
                setState(RUNNING_STATE);
                break;
            case STOPPING_STATE:
                System.out.println("电梯运行");
                setState(RUNNING_STATE);
                break;
            case RUNNING_STATE:
                break;
        }
    }

    @Override
    public void stop() {
        switch (state){
            case OPENING_STATE:
                break;
            case CLOSING_STATE:
                break;
            case STOPPING_STATE:
                break;
            case RUNNING_STATE:
                System.out.println("电梯停止");
                break;
        }
    }
}
