package yxy.pattern.behavior.memento.white_box;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 22:58
 * 备忘录管理者角色 管理对象的备忘录
 */
public class RoleStateCaretaker {
    private RoleStateMemento roleStateMemento;

    public RoleStateMemento getRoleStateMemento() {
        return roleStateMemento;
    }

    public void setRoleStateMemento(RoleStateMemento roleStateMemento) {
        this.roleStateMemento = roleStateMemento;
    }
}
