package yxy.pattern.behavior.memento.black_box;


/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 23:02
 */
public class RoleStateCaretaker {

    //声明RoleStateMemento类型的变量
    private Memento memento;

    public Memento getMemento() {
        return memento;
    }

    public void setMemento(Memento memento) {
        this.memento = memento;
    }
}
