package yxy.pattern.behavior.memento.black_box;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 23:02
 * 备忘录接口 对外提供窄接口
 */
public interface Memento {
}
