package yxy.pattern.behavior.chain_of_responsibility;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 18:58
 */
public class Manager extends Handler{
    public Manager() {
        super(NUM_ONE,NUM_THREE);
    }

    @Override
    protected void handleLeave(LeaveRequest leaveRequest) {
        System.out.println("部门经理批准"+leaveRequest.getName()+"请假"+leaveRequest.getNum()+"天,"+leaveRequest.getContent());
        System.out.println("部门经理审批:同意");
    }
}