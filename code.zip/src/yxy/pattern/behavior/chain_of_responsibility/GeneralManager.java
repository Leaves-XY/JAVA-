package yxy.pattern.behavior.chain_of_responsibility;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 18:59
 */
public class GeneralManager extends Handler{
    public GeneralManager() {
        super(NUM_THREE,NUM_SEVEN);
    }

    @Override
    protected void handleLeave(LeaveRequest leaveRequest) {
        System.out.println("总经理批准"+leaveRequest.getName()+"请假"+leaveRequest.getNum()+"天,"+leaveRequest.getContent());
        System.out.println("总经理审批:同意");
    }
}
