package yxy.pattern.behavior.chain_of_responsibility;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 18:45
 * 请假请求
 */
public class LeaveRequest {
    public String name;

    //请假天数
    public int num;

    public String content;

    public LeaveRequest(String name, int num, String content) {
        this.name = name;
        this.num = num;
        this.content = content;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
