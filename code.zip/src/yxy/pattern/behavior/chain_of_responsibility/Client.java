package yxy.pattern.behavior.chain_of_responsibility;

import yxy.pattern.creator.builder.demo1.Director;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 18:59
 */
public class Client {
    public static void main(String[] args) {
        LeaveRequest leave = new LeaveRequest("张三", 8, "身体不适");

        // 创建责任链
        Handler groupLeader = new GroupLeader();
        Handler manager = new Manager();
        Handler generalManager = new GeneralManager();

        // 设置责任链
        groupLeader.setNextHandler(manager);
        manager.setNextHandler(generalManager);

        // 发起请求
        groupLeader.submit(leave);
    }
}
