package yxy.pattern.behavior.chain_of_responsibility;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 18:55
 */
public class GroupLeader extends Handler{
    public GroupLeader() {
        super(0,NUM_ONE);
    }

    @Override
    protected void handleLeave(LeaveRequest leaveRequest) {
        System.out.println("组长批准"+leaveRequest.getName()+"请假"+leaveRequest.getNum()+"天,"+leaveRequest.getContent());
        System.out.println("组长审批:同意");
    }
}
