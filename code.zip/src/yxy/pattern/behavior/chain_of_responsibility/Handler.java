package yxy.pattern.behavior.chain_of_responsibility;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 18:46
 * 抽象处理者
 */
public abstract class Handler {
    protected final static int NUM_ONE=1;
    protected final static int NUM_THREE=3;
    protected final static int NUM_SEVEN=7;

    //该领导处理的请假天数区间
    private int numStart;
    private int numEnd;

    //声明后继者
    private Handler nextHandler;

    public Handler(int numStart) {
        this.numStart = numStart;
    }

    public Handler(int numStart, int numEnd) {
        this.numStart = numStart;
        this.numEnd = numEnd;
    }

    public Handler(int numStart, int numEnd, Handler nextHandler) {
        this.numStart = numStart;
        this.numEnd = numEnd;
        this.nextHandler = nextHandler;
    }

    //设置上级领导
    public void setNextHandler(Handler nextHandler) {
        this.nextHandler = nextHandler;
    }

    //各级领导处理请假的方法
    protected abstract void handleLeave(LeaveRequest leaveRequest);

    //提交请假条
    public final void submit(LeaveRequest leaveRequest){
        //如果请假天数在该领导的处理范围内，该领导就处理，否则交给上级领导处理
        this.handleLeave(leaveRequest);
        if(this.nextHandler!=null&&leaveRequest.getNum()>numEnd){
            //交给上级领导处理
            nextHandler.submit(leaveRequest);
        }else{
            System.out.println("处理完毕");
        }
    }
}
