package yxy.pattern.behavior.iterator;

import java.util.List;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 21:32
 */
public class StudentIteratorImpl implements StudentIterator{
    private List<Student> list;
    private int position = 0; //记录遍历的位置

    public StudentIteratorImpl(List<Student> list) {
        this.list = list;
    }

    @Override
    public boolean hasNext() {
        return position < list.size();
    }

    @Override
    public Student next() {
        //从集合中获取下一个元素
        Student currentStudent = list.get(position);
        position++;
        return currentStudent;
    }
}
