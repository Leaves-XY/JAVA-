package yxy.pattern.behavior.iterator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 21:28
 */
public interface StudentIterator {
    //判断是否还有下一个元素
    boolean hasNext();
    //获取下一个元素
    Student next();
}

