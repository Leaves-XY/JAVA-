package yxy.pattern.behavior.iterator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 21:39
 */
public class Client {
    public static void main(String[] args) {
        StudentAggregate studentAggregate = new StudentAggregateImpl();

        Student student1=new Student("张三","1");
        Student student2=new Student("李四","2");
        Student student3=new Student("王五","3");
        Student student4=new Student("赵六","4");
        Student student5=new Student("孙七","5");
        studentAggregate.addStudent(student1);
        studentAggregate.addStudent(student2);
        studentAggregate.addStudent(student3);
        studentAggregate.addStudent(student4);
        studentAggregate.addStudent(student5);

        StudentIterator studentIterator = studentAggregate.getStudentIterator();
        while (studentIterator.hasNext()){
            Student next = studentIterator.next();
            System.out.println(next.getName());
        }

    }
}
