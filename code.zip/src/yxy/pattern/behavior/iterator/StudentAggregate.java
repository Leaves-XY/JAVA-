package yxy.pattern.behavior.iterator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 21:34
 * 迭代器模式 抽象聚合类
 */
public interface StudentAggregate {
    //添加学生
    void addStudent(Student student);

    //删除学生
    void removeStudent(Student student);

    //获取迭代器
    StudentIterator getStudentIterator();
}
