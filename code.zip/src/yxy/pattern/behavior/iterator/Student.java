package yxy.pattern.behavior.iterator;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 21:28
 */
public class Student {
    private String name;
    private String number;

    public Student() {

    }

    public Student(String name, String number) {
        this.name = name;
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
