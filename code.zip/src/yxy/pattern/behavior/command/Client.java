package yxy.pattern.behavior.command;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 18:26
 */
public class Client {
    public static void main(String[] args) {
        Order order1 = new Order();
        order1.setDiningTable(1);
        order1.setFood("西红柿炒鸡蛋",1);
        order1.setFood("小炒肉",2);
        order1.setFood("可乐",2);

        Order order2 = new Order();
        order2.setDiningTable(2);
        order2.setFood("鱼香肉丝",1);
        order2.setFood("回锅肉",2);
        order2.setFood("雪碧",2);

        SeniorChef receiver = new SeniorChef();

        Command command1 = new OrderCommand(receiver,order1);
        Command command2 = new OrderCommand(receiver,order2);

        Waiter waiter = new Waiter();
        waiter.setCommand(command1);
        waiter.setCommand(command2);

        waiter.orderUp();
    }
}
