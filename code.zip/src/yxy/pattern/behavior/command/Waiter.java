package yxy.pattern.behavior.command;

import java.util.ArrayList;
import java.util.List;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 18:24
 * 服务员 用来操作命令的上下文环境 也就是调用者
 */
public class Waiter {
    private List<Command> commands=new ArrayList<>();

    public void setCommand(Command command){
        commands.add(command);
    }

    public void orderUp(){
        System.out.println("大厨，新订单来了");
        for (Command command : commands) {
            if (command!=null)
                command.execute();
        }
    }
}
