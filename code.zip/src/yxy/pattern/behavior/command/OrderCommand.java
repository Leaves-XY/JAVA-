package yxy.pattern.behavior.command;

import java.util.Map;
import java.util.Set;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 18:17
 * 命令模式 命令类 也就是命令的具体实现者
 */
public class OrderCommand implements Command{
    //命令模式的核心是命令类，命令类中需要有执行者
    private SeniorChef receiver;
    private Order order;

    public OrderCommand(SeniorChef receiver, Order order) {
        this.receiver = receiver;
        this.order = order;
    }

    @Override
    public void execute() {
        System.out.println(order.getDiningTable()+"号桌的订单");
        Map<String,Integer> foodDir=order.getFoodDir();
        Set<String> keys=foodDir.keySet();

        for (String foodName : keys) {
            receiver.makeFood(foodName,foodDir.get(foodName));
        }

        System.out.println(order.getDiningTable()+"号桌的订单做好了");
    }

}
