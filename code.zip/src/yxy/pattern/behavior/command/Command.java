package yxy.pattern.behavior.command;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 18:13
 * 命令模式
 */
public interface Command {
    void execute();
}
