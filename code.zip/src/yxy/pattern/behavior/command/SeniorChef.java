package yxy.pattern.behavior.command;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 18:15
 * 命令模式 高级厨师 也就是命令的接收者
 */
public class SeniorChef {
    public void makeFood(String name,int num){
        System.out.println("高级厨师正在做"+name+"*"+num);
    }
}
