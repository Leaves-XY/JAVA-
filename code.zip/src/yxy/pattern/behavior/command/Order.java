package yxy.pattern.behavior.command;

import java.util.HashMap;
import java.util.Map;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/25 18:13
 * 命令模式 订单类
 */
public class Order {
    //餐桌号码
    private int diningTable;

    //所下的餐品和数量
    private Map<String,Integer> foodDir=new HashMap<>();

    public void setFood(String name,int num){
        foodDir.put(name,num);
    }

    public int getDiningTable() {
        return diningTable;
    }

    public void setDiningTable(int diningTable) {
        this.diningTable = diningTable;
    }

    public Map<String, Integer> getFoodDir() {
        return foodDir;
    }

    public void setFoodDir(Map<String, Integer> foodDir) {
        this.foodDir = foodDir;
    }
}

