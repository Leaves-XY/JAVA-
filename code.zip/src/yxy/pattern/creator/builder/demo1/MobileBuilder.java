package yxy.pattern.creator.builder.demo1;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 21:47
 * 具体的建造者
 */
public class MobileBuilder extends Builder {
    @Override
    public void buildFrame() {
        bike.setFrame("碳纤维车架");
    }

    @Override
    public void buildSeat() {
        bike.setSeat("真皮车座");
    }

    @Override
    public Bike createBike() {
        return bike;
    }
}

