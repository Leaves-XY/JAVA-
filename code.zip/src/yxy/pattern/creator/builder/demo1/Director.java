package yxy.pattern.creator.builder.demo1;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 21:49
 */
public class Director {
    //声明Builder类型的变量
    private Builder builder;

    public Director(Builder builder) {
        this.builder = builder;
    }

    //组装自行车
    public Bike construct(){
        builder.buildFrame();
        builder.buildSeat();
        return builder.createBike();
    }
}
