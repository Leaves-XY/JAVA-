package yxy.pattern.creator.builder.demo1;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 21:51
 */
public class Client {
    public static void main(String[] args) {
        //创建具体的建造者
        Director director = new Director(new MobileBuilder());
        //指挥者指挥组装自行车
        Bike bike = director.construct();

        System.out.println(bike.getFrame());
        System.out.println(bike.getSeat());

        director = new Director(new OfoBuilder());
        bike = director.construct();
        System.out.println(bike.getFrame());
        System.out.println(bike.getSeat());
    }
}
