package yxy.pattern.creator.builder.demo1;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 21:48
 */
public class OfoBuilder extends Builder{
    @Override
    public void buildFrame() {
        bike.setFrame("铝合金车架");
    }

    @Override
    public void buildSeat() {
        bike.setSeat("橡胶车座");
    }

    @Override
    public Bike createBike() {
        return bike;
    }
}
