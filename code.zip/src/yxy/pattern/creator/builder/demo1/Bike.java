package yxy.pattern.creator.builder.demo1;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 21:44
 * 产品类
 */
public class Bike {
    private String frame;//车架

    private String seat;//车座

    public String getFrame() {
        return frame;
    }

    public void setFrame(String frame) {
        this.frame = frame;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }
}
