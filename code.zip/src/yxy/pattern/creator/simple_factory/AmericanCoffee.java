package yxy.pattern.creator.simple_factory;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 23:30
 */
public class AmericanCoffee extends Coffee{
    @Override
    public String getName() {
        return "美式咖啡";
    }
}
