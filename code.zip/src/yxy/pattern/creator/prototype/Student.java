package yxy.pattern.creator.prototype;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 21:27
 */
public class Student {
    private String name;

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
