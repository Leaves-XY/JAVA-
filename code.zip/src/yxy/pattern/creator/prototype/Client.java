package yxy.pattern.creator.prototype;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 21:17
 * 原型模式
 */
public class Client {
    public static void main(String[] args) {
        Realizetype realizetype = new Realizetype();
        try {
            Realizetype clone =realizetype.clone();
            //判断是否是同一个对象 false
            System.out.println(realizetype == clone);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
    }
}
