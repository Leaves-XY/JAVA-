package yxy.pattern.creator.prototype;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 21:23
 * 原型模式 浅克隆 克隆对象和原型对象的引用类型的属性指向同一个对象
 */
public class CitationTest {
    public static void main(String[] args) throws CloneNotSupportedException{
        Citation citation=new Citation();

        Student stu=new Student();
        stu.setName("张三");
        citation.setStu(stu);

        Citation citation1=  citation.clone();
        citation1.getStu().setName("李四");
    /*    citation.setName("张三");
        citation1.setName("李四");*/
        citation.show();
        citation1.show();
    }
}
