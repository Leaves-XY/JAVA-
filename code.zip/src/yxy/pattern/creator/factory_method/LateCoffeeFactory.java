package yxy.pattern.creator.factory_method;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 23:51
 */
public class LateCoffeeFactory implements CoffeeFactory{
    @Override
    public Coffee createCoffee() {
        return new LatteCoffee();
    }
}
