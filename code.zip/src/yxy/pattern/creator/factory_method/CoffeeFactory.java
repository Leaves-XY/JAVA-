package yxy.pattern.creator.factory_method;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 23:49
 * 抽象工厂
 */
public interface CoffeeFactory {
    //创建咖啡对象方法
    Coffee createCoffee();
}
