package yxy.pattern.creator.factory_method;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 23:50
 */
public class AmericanCoffeeFactory implements CoffeeFactory{
    @Override
    public Coffee createCoffee() {
        return new AmericanCoffee();
    }
}
