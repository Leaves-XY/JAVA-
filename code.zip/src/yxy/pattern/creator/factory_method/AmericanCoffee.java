package yxy.pattern.creator.factory_method;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 23:30
 * 具体产品 美式咖啡
 */
public class AmericanCoffee extends Coffee {
    @Override
    public String getName() {
        return "美式咖啡";
    }
}
