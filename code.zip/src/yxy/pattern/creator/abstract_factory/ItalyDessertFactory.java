package yxy.pattern.creator.abstract_factory;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 0:37
 * 具体工厂 意大利甜品工厂 生产拿铁咖啡和提拉米苏
 */
public class ItalyDessertFactory implements DessertFactory{
    @Override
    public Coffee createCoffee() {
        return new LatteCoffee();
    }

    @Override
    public Dessert createDessert() {
        return new Trimisu();
    }
}
