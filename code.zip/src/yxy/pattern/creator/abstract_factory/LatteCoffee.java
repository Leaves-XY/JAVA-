package yxy.pattern.creator.abstract_factory;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 23:30
 */
public class LatteCoffee extends Coffee {
    @Override
    public String getName() {
        return "拿铁咖啡";
    }
}
