package yxy.pattern.creator.abstract_factory;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 0:35
 */
public interface DessertFactory {
    //生产咖啡
    Coffee createCoffee();
    //生产甜品
    Dessert createDessert();
}
