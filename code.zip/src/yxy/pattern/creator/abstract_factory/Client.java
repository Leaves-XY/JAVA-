package yxy.pattern.creator.abstract_factory;

import yxy.pattern.creator.factory_method.AmericanCoffeeFactory;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/23 0:38
 */
public class Client {
    public static void main(String[] args) {
        //创建意大利咖啡工厂
//        ItalyDessertFactory factory = new ItalyDessertFactory();
        AmericanDessertFactory factory = new AmericanDessertFactory();
        //获取拿铁咖啡和提拉米苏
        Coffee coffee = factory.createCoffee();
        Dessert dessert = factory.createDessert();
        System.out.println(coffee.getName());
        dessert.show();
    }
}
