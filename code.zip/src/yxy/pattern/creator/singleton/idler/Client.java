package yxy.pattern.creator.singleton.idler;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 22:34
 */
public class Client {
    public static void main(String[] args) {
        Singleton instance = Singleton.getInstance();
        Singleton instance1 = Singleton.getInstance();
        //判断是否是同一个对象 true 说明是同一个对象
        System.out.println(instance==instance1);
    }
}
