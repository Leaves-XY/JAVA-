package yxy.pattern.creator.singleton.idler;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 22:33
 * 懒汉式,问题：加了锁，效率低
 */

public class Singleton {
    //1.私有化构造器 使得外部不能new
    private Singleton() {}

    //2.创建本类的唯一实例
    private static Singleton instance;

    //3.提供一个公共的访问方法，使得外部可以获取该实例
    public static synchronized Singleton getInstance() {
        if (instance == null) {
            //线程1执行到此处，线程2也执行到此处，此时instance为null，线程1和线程2都会进入if语句块
            instance = new Singleton();
        }
        return instance;
    }
}
