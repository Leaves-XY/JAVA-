package yxy.pattern.creator.singleton.hunger_man;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 22:31
 * 饿汉式（静态代码块）
 */
public class Singleton2 {
    //1.私有化构造器 使得外部不能new
    private Singleton2() {}

    //2.创建本类的唯一实例
    private static Singleton2 instance; //null

    //在静态代码块中创建单例对象
    static {
        instance = new Singleton2();
    }

    //3.提供一个公共的访问方法，使得外部可以获取该实例
    public static Singleton2 getInstance() {
        return instance;
    }
}
