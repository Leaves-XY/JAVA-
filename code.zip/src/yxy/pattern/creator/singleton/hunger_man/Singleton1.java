package yxy.pattern.creator.singleton.hunger_man;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 22:29
 * 饿汉式（静态变量）
 */
public class Singleton1 {
    //1.私有化构造器 使得外部不能new
    private Singleton1() {}

    //2.创建本类的唯一实例
    private static Singleton1 instance = new Singleton1();

    //3.提供一个公共的访问方法，使得外部可以获取该实例
    public static Singleton1 getInstance() {
        return instance;
    }
}
