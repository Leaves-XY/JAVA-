package yxy.pattern.creator.singleton.hunger_man;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 22:30
 */
public class Client {
    public static void main(String[] args) {
        Singleton1 instance = Singleton1.getInstance();
        Singleton1 instance1 = Singleton1.getInstance();
        //判断是否是同一个对象 true 说明是同一个对象
        System.out.println(instance==instance1);

        Singleton2 instance2 = Singleton2.getInstance();
        Singleton2 instance3 = Singleton2.getInstance();

        System.out.println(instance2==instance3);
    }
}
