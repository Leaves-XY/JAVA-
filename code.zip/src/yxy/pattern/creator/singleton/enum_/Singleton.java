package yxy.pattern.creator.singleton.enum_;

/**
 * @author YeXingyi
 * @version 1.0
 * @date 2023/10/22 22:52
 * 枚举实现单例
 */
public enum Singleton {
    INSTANCE;
}
